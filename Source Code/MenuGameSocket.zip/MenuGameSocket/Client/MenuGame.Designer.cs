﻿namespace Client
{
    partial class rbMenuGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(rbMenuGame));
            this.menuTabControl = new System.Windows.Forms.TabControl();
            this.GiaiTri = new System.Windows.Forms.TabPage();
            this.LbGGPlus = new System.Windows.Forms.Label();
            this.lbZalo = new System.Windows.Forms.Label();
            this.lbTwitter = new System.Windows.Forms.Label();
            this.lbYouTuBe = new System.Windows.Forms.Label();
            this.lbZingMe = new System.Windows.Forms.Label();
            this.lbFaceBook = new System.Windows.Forms.Label();
            this.lbBaVuongChiMong = new System.Windows.Forms.Label();
            this.pbBaVuong = new System.Windows.Forms.PictureBox();
            this.pbGGPlus = new System.Windows.Forms.PictureBox();
            this.pbTwister = new System.Windows.Forms.PictureBox();
            this.pbYouTuBe = new System.Windows.Forms.PictureBox();
            this.pbZalo = new System.Windows.Forms.PictureBox();
            this.pbZingMe = new System.Windows.Forms.PictureBox();
            this.pbFacebook = new System.Windows.Forms.PictureBox();
            this.lbĐBVõLâm = new System.Windows.Forms.Label();
            this.pbĐBVõLâm = new System.Windows.Forms.PictureBox();
            this.lbRa2 = new System.Windows.Forms.Label();
            this.lb3Q = new System.Windows.Forms.Label();
            this.lbKVTrenMay = new System.Windows.Forms.Label();
            this.lbGunny = new System.Windows.Forms.Label();
            this.lbVLChiMong = new System.Windows.Forms.Label();
            this.pbRa2 = new System.Windows.Forms.PictureBox();
            this.pbGunny = new System.Windows.Forms.PictureBox();
            this.pbKVTrenMay = new System.Windows.Forms.PictureBox();
            this.pb3Q = new System.Windows.Forms.PictureBox();
            this.pbVLChiMong = new System.Windows.Forms.PictureBox();
            this.TinTuc = new System.Windows.Forms.TabPage();
            this.lbTuoiTre = new System.Windows.Forms.Label();
            this.lbThanhNien = new System.Windows.Forms.Label();
            this.lbGiaDinh = new System.Windows.Forms.Label();
            this.lbVnExpress = new System.Windows.Forms.Label();
            this.lbDanTri = new System.Windows.Forms.Label();
            this.lbBaoMoi = new System.Windows.Forms.Label();
            this.lb24H = new System.Windows.Forms.Label();
            this.pbTuoiTre = new System.Windows.Forms.PictureBox();
            this.pbThanhNien = new System.Windows.Forms.PictureBox();
            this.pbTiepThiGiaDinh = new System.Windows.Forms.PictureBox();
            this.pbVnexpress = new System.Windows.Forms.PictureBox();
            this.pbDanTriNews = new System.Windows.Forms.PictureBox();
            this.pbBaoMoiNews = new System.Windows.Forms.PictureBox();
            this.pb24hNews = new System.Windows.Forms.PictureBox();
            this.Nhac = new System.Windows.Forms.TabPage();
            this.lbNhacSo = new System.Windows.Forms.Label();
            this.lbNhacVui = new System.Windows.Forms.Label();
            this.lbZingMp3 = new System.Windows.Forms.Label();
            this.lbNCT = new System.Windows.Forms.Label();
            this.pbNhacSo = new System.Windows.Forms.PictureBox();
            this.pbNhacVui = new System.Windows.Forms.PictureBox();
            this.pbMp3Zing = new System.Windows.Forms.PictureBox();
            this.pbNCT = new System.Windows.Forms.PictureBox();
            this.UngDungCuaMay = new System.Windows.Forms.TabPage();
            this.Zalo = new System.Windows.Forms.Label();
            this.pbZaloPC = new System.Windows.Forms.PictureBox();
            this.lbVisual = new System.Windows.Forms.Label();
            this.pbVisual = new System.Windows.Forms.PictureBox();
            this.lbBida = new System.Windows.Forms.Label();
            this.pbBiDaFlash = new System.Windows.Forms.PictureBox();
            this.lbZaloPC = new System.Windows.Forms.Label();
            this.pbRa2OFF = new System.Windows.Forms.PictureBox();
            this.lbChome = new System.Windows.Forms.Label();
            this.pbChrome = new System.Windows.Forms.PictureBox();
            this.lbMyComputer = new System.Windows.Forms.Label();
            this.pbMyComputer = new System.Windows.Forms.PictureBox();
            this.lbConnect = new System.Windows.Forms.Label();
            this.tbMessage = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuTabControl.SuspendLayout();
            this.GiaiTri.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbBaVuong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGGPlus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTwister)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbYouTuBe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbZalo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbZingMe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFacebook)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbĐBVõLâm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRa2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGunny)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbKVTrenMay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3Q)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbVLChiMong)).BeginInit();
            this.TinTuc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbTuoiTre)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbThanhNien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTiepThiGiaDinh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbVnexpress)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDanTriNews)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBaoMoiNews)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb24hNews)).BeginInit();
            this.Nhac.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbNhacSo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbNhacVui)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMp3Zing)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbNCT)).BeginInit();
            this.UngDungCuaMay.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbZaloPC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbVisual)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBiDaFlash)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRa2OFF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbChrome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMyComputer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuTabControl
            // 
            this.menuTabControl.Controls.Add(this.GiaiTri);
            this.menuTabControl.Controls.Add(this.TinTuc);
            this.menuTabControl.Controls.Add(this.Nhac);
            this.menuTabControl.Controls.Add(this.UngDungCuaMay);
            this.menuTabControl.ItemSize = new System.Drawing.Size(64, 26);
            this.menuTabControl.Location = new System.Drawing.Point(-5, -1);
            this.menuTabControl.Name = "menuTabControl";
            this.menuTabControl.Padding = new System.Drawing.Point(30, 3);
            this.menuTabControl.SelectedIndex = 0;
            this.menuTabControl.Size = new System.Drawing.Size(793, 463);
            this.menuTabControl.TabIndex = 0;
            // 
            // GiaiTri
            // 
            this.GiaiTri.BackColor = System.Drawing.Color.White;
            this.GiaiTri.Controls.Add(this.LbGGPlus);
            this.GiaiTri.Controls.Add(this.lbZalo);
            this.GiaiTri.Controls.Add(this.lbTwitter);
            this.GiaiTri.Controls.Add(this.lbYouTuBe);
            this.GiaiTri.Controls.Add(this.lbZingMe);
            this.GiaiTri.Controls.Add(this.lbFaceBook);
            this.GiaiTri.Controls.Add(this.lbBaVuongChiMong);
            this.GiaiTri.Controls.Add(this.pbBaVuong);
            this.GiaiTri.Controls.Add(this.pbGGPlus);
            this.GiaiTri.Controls.Add(this.pbTwister);
            this.GiaiTri.Controls.Add(this.pbYouTuBe);
            this.GiaiTri.Controls.Add(this.pbZalo);
            this.GiaiTri.Controls.Add(this.pbZingMe);
            this.GiaiTri.Controls.Add(this.pbFacebook);
            this.GiaiTri.Controls.Add(this.lbĐBVõLâm);
            this.GiaiTri.Controls.Add(this.pbĐBVõLâm);
            this.GiaiTri.Controls.Add(this.lbRa2);
            this.GiaiTri.Controls.Add(this.lb3Q);
            this.GiaiTri.Controls.Add(this.lbKVTrenMay);
            this.GiaiTri.Controls.Add(this.lbGunny);
            this.GiaiTri.Controls.Add(this.lbVLChiMong);
            this.GiaiTri.Controls.Add(this.pbRa2);
            this.GiaiTri.Controls.Add(this.pbGunny);
            this.GiaiTri.Controls.Add(this.pbKVTrenMay);
            this.GiaiTri.Controls.Add(this.pb3Q);
            this.GiaiTri.Controls.Add(this.pbVLChiMong);
            this.GiaiTri.Cursor = System.Windows.Forms.Cursors.Hand;
            this.GiaiTri.ForeColor = System.Drawing.Color.Black;
            this.GiaiTri.Location = new System.Drawing.Point(4, 30);
            this.GiaiTri.Name = "GiaiTri";
            this.GiaiTri.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.GiaiTri.Size = new System.Drawing.Size(785, 429);
            this.GiaiTri.TabIndex = 0;
            this.GiaiTri.Text = "Giải Trí";
            // 
            // LbGGPlus
            // 
            this.LbGGPlus.AutoSize = true;
            this.LbGGPlus.Location = new System.Drawing.Point(45, 376);
            this.LbGGPlus.Name = "LbGGPlus";
            this.LbGGPlus.Size = new System.Drawing.Size(35, 21);
            this.LbGGPlus.TabIndex = 38;
            this.LbGGPlus.Text = "G+";
            // 
            // lbZalo
            // 
            this.lbZalo.AutoSize = true;
            this.lbZalo.Location = new System.Drawing.Point(694, 246);
            this.lbZalo.Name = "lbZalo";
            this.lbZalo.Size = new System.Drawing.Size(43, 21);
            this.lbZalo.TabIndex = 37;
            this.lbZalo.Text = "Zalo";
            // 
            // lbTwitter
            // 
            this.lbTwitter.AutoSize = true;
            this.lbTwitter.Location = new System.Drawing.Point(552, 246);
            this.lbTwitter.Name = "lbTwitter";
            this.lbTwitter.Size = new System.Drawing.Size(62, 21);
            this.lbTwitter.TabIndex = 36;
            this.lbTwitter.Text = "Twitter";
            // 
            // lbYouTuBe
            // 
            this.lbYouTuBe.AutoSize = true;
            this.lbYouTuBe.Location = new System.Drawing.Point(415, 246);
            this.lbYouTuBe.Name = "lbYouTuBe";
            this.lbYouTuBe.Size = new System.Drawing.Size(80, 21);
            this.lbYouTuBe.TabIndex = 35;
            this.lbYouTuBe.Text = "YouTuBe";
            // 
            // lbZingMe
            // 
            this.lbZingMe.AutoSize = true;
            this.lbZingMe.Location = new System.Drawing.Point(287, 246);
            this.lbZingMe.Name = "lbZingMe";
            this.lbZingMe.Size = new System.Drawing.Size(72, 21);
            this.lbZingMe.TabIndex = 34;
            this.lbZingMe.Text = "Zing Me";
            // 
            // lbFaceBook
            // 
            this.lbFaceBook.AutoSize = true;
            this.lbFaceBook.Location = new System.Drawing.Point(149, 246);
            this.lbFaceBook.Name = "lbFaceBook";
            this.lbFaceBook.Size = new System.Drawing.Size(87, 21);
            this.lbFaceBook.TabIndex = 33;
            this.lbFaceBook.Text = "FaceBook";
            // 
            // lbBaVuongChiMong
            // 
            this.lbBaVuongChiMong.AutoSize = true;
            this.lbBaVuongChiMong.Location = new System.Drawing.Point(21, 246);
            this.lbBaVuongChiMong.Name = "lbBaVuongChiMong";
            this.lbBaVuongChiMong.Size = new System.Drawing.Size(86, 21);
            this.lbBaVuongChiMong.TabIndex = 32;
            this.lbBaVuongChiMong.Text = "Bá Vương";
            // 
            // pbBaVuong
            // 
            this.pbBaVuong.Image = ((System.Drawing.Image)(resources.GetObject("pbBaVuong.Image")));
            this.pbBaVuong.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbBaVuong.InitialImage")));
            this.pbBaVuong.Location = new System.Drawing.Point(13, 143);
            this.pbBaVuong.Name = "pbBaVuong";
            this.pbBaVuong.Size = new System.Drawing.Size(100, 100);
            this.pbBaVuong.TabIndex = 31;
            this.pbBaVuong.TabStop = false;
            this.pbBaVuong.Click += new System.EventHandler(this.pbBaVuong_Click);
            // 
            // pbGGPlus
            // 
            this.pbGGPlus.Image = ((System.Drawing.Image)(resources.GetObject("pbGGPlus.Image")));
            this.pbGGPlus.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbGGPlus.InitialImage")));
            this.pbGGPlus.Location = new System.Drawing.Point(13, 273);
            this.pbGGPlus.Name = "pbGGPlus";
            this.pbGGPlus.Size = new System.Drawing.Size(100, 100);
            this.pbGGPlus.TabIndex = 30;
            this.pbGGPlus.TabStop = false;
            this.pbGGPlus.Click += new System.EventHandler(this.pbGGPlus_Click);
            // 
            // pbTwister
            // 
            this.pbTwister.Image = ((System.Drawing.Image)(resources.GetObject("pbTwister.Image")));
            this.pbTwister.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbTwister.InitialImage")));
            this.pbTwister.Location = new System.Drawing.Point(533, 143);
            this.pbTwister.Name = "pbTwister";
            this.pbTwister.Size = new System.Drawing.Size(100, 100);
            this.pbTwister.TabIndex = 29;
            this.pbTwister.TabStop = false;
            this.pbTwister.Click += new System.EventHandler(this.pbTwister_Click);
            // 
            // pbYouTuBe
            // 
            this.pbYouTuBe.Image = ((System.Drawing.Image)(resources.GetObject("pbYouTuBe.Image")));
            this.pbYouTuBe.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbYouTuBe.InitialImage")));
            this.pbYouTuBe.Location = new System.Drawing.Point(403, 143);
            this.pbYouTuBe.Name = "pbYouTuBe";
            this.pbYouTuBe.Size = new System.Drawing.Size(100, 100);
            this.pbYouTuBe.TabIndex = 28;
            this.pbYouTuBe.TabStop = false;
            this.pbYouTuBe.Click += new System.EventHandler(this.pbYouTuBe_Click);
            // 
            // pbZalo
            // 
            this.pbZalo.Image = ((System.Drawing.Image)(resources.GetObject("pbZalo.Image")));
            this.pbZalo.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbZalo.InitialImage")));
            this.pbZalo.Location = new System.Drawing.Point(663, 143);
            this.pbZalo.Name = "pbZalo";
            this.pbZalo.Size = new System.Drawing.Size(100, 100);
            this.pbZalo.TabIndex = 27;
            this.pbZalo.TabStop = false;
            this.pbZalo.Click += new System.EventHandler(this.pbZalo_Click);
            // 
            // pbZingMe
            // 
            this.pbZingMe.Image = ((System.Drawing.Image)(resources.GetObject("pbZingMe.Image")));
            this.pbZingMe.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbZingMe.InitialImage")));
            this.pbZingMe.Location = new System.Drawing.Point(273, 143);
            this.pbZingMe.Name = "pbZingMe";
            this.pbZingMe.Size = new System.Drawing.Size(100, 100);
            this.pbZingMe.TabIndex = 26;
            this.pbZingMe.TabStop = false;
            this.pbZingMe.Click += new System.EventHandler(this.pbZingMe_Click);
            // 
            // pbFacebook
            // 
            this.pbFacebook.Image = ((System.Drawing.Image)(resources.GetObject("pbFacebook.Image")));
            this.pbFacebook.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbFacebook.InitialImage")));
            this.pbFacebook.Location = new System.Drawing.Point(143, 143);
            this.pbFacebook.Name = "pbFacebook";
            this.pbFacebook.Size = new System.Drawing.Size(100, 100);
            this.pbFacebook.TabIndex = 25;
            this.pbFacebook.TabStop = false;
            this.pbFacebook.Click += new System.EventHandler(this.pbFacebook_Click);
            // 
            // lbĐBVõLâm
            // 
            this.lbĐBVõLâm.AutoSize = true;
            this.lbĐBVõLâm.Location = new System.Drawing.Point(661, 116);
            this.lbĐBVõLâm.Name = "lbĐBVõLâm";
            this.lbĐBVõLâm.Size = new System.Drawing.Size(102, 21);
            this.lbĐBVõLâm.TabIndex = 24;
            this.lbĐBVõLâm.Text = "ĐB Võ Lâm";
            // 
            // pbĐBVõLâm
            // 
            this.pbĐBVõLâm.Image = ((System.Drawing.Image)(resources.GetObject("pbĐBVõLâm.Image")));
            this.pbĐBVõLâm.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbĐBVõLâm.InitialImage")));
            this.pbĐBVõLâm.Location = new System.Drawing.Point(663, 13);
            this.pbĐBVõLâm.Name = "pbĐBVõLâm";
            this.pbĐBVõLâm.Size = new System.Drawing.Size(100, 100);
            this.pbĐBVõLâm.TabIndex = 23;
            this.pbĐBVõLâm.TabStop = false;
            this.pbĐBVõLâm.Click += new System.EventHandler(this.pbĐBVõLâm_Click);
            // 
            // lbRa2
            // 
            this.lbRa2.AutoSize = true;
            this.lbRa2.Location = new System.Drawing.Point(564, 116);
            this.lbRa2.Name = "lbRa2";
            this.lbRa2.Size = new System.Drawing.Size(40, 21);
            this.lbRa2.TabIndex = 22;
            this.lbRa2.Text = "Ra2";
            // 
            // lb3Q
            // 
            this.lb3Q.AutoSize = true;
            this.lb3Q.Location = new System.Drawing.Point(437, 116);
            this.lb3Q.Name = "lb3Q";
            this.lb3Q.Size = new System.Drawing.Size(33, 21);
            this.lb3Q.TabIndex = 21;
            this.lb3Q.Text = "3Q";
            // 
            // lbKVTrenMay
            // 
            this.lbKVTrenMay.AutoSize = true;
            this.lbKVTrenMay.Location = new System.Drawing.Point(269, 116);
            this.lbKVTrenMay.Name = "lbKVTrenMay";
            this.lbKVTrenMay.Size = new System.Drawing.Size(113, 21);
            this.lbKVTrenMay.TabIndex = 20;
            this.lbKVTrenMay.Text = "KV Trên Mây";
            // 
            // lbGunny
            // 
            this.lbGunny.AutoSize = true;
            this.lbGunny.Location = new System.Drawing.Point(161, 116);
            this.lbGunny.Name = "lbGunny";
            this.lbGunny.Size = new System.Drawing.Size(60, 21);
            this.lbGunny.TabIndex = 19;
            this.lbGunny.Text = "Gunny";
            // 
            // lbVLChiMong
            // 
            this.lbVLChiMong.AutoSize = true;
            this.lbVLChiMong.Location = new System.Drawing.Point(9, 116);
            this.lbVLChiMong.Name = "lbVLChiMong";
            this.lbVLChiMong.Size = new System.Drawing.Size(113, 21);
            this.lbVLChiMong.TabIndex = 18;
            this.lbVLChiMong.Text = "VL Chi Mộng";
            // 
            // pbRa2
            // 
            this.pbRa2.Image = ((System.Drawing.Image)(resources.GetObject("pbRa2.Image")));
            this.pbRa2.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbRa2.InitialImage")));
            this.pbRa2.Location = new System.Drawing.Point(533, 13);
            this.pbRa2.Name = "pbRa2";
            this.pbRa2.Size = new System.Drawing.Size(100, 100);
            this.pbRa2.TabIndex = 5;
            this.pbRa2.TabStop = false;
            this.pbRa2.Click += new System.EventHandler(this.pbRa2_Click);
            // 
            // pbGunny
            // 
            this.pbGunny.Image = ((System.Drawing.Image)(resources.GetObject("pbGunny.Image")));
            this.pbGunny.Location = new System.Drawing.Point(143, 13);
            this.pbGunny.Name = "pbGunny";
            this.pbGunny.Size = new System.Drawing.Size(100, 100);
            this.pbGunny.TabIndex = 3;
            this.pbGunny.TabStop = false;
            this.pbGunny.Click += new System.EventHandler(this.pbGunny_Click);
            // 
            // pbKVTrenMay
            // 
            this.pbKVTrenMay.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbKVTrenMay.BackgroundImage")));
            this.pbKVTrenMay.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbKVTrenMay.InitialImage")));
            this.pbKVTrenMay.Location = new System.Drawing.Point(273, 13);
            this.pbKVTrenMay.Name = "pbKVTrenMay";
            this.pbKVTrenMay.Size = new System.Drawing.Size(100, 100);
            this.pbKVTrenMay.TabIndex = 2;
            this.pbKVTrenMay.TabStop = false;
            this.pbKVTrenMay.Click += new System.EventHandler(this.pbKVTrenMay_Click);
            // 
            // pb3Q
            // 
            this.pb3Q.Image = ((System.Drawing.Image)(resources.GetObject("pb3Q.Image")));
            this.pb3Q.InitialImage = ((System.Drawing.Image)(resources.GetObject("pb3Q.InitialImage")));
            this.pb3Q.Location = new System.Drawing.Point(403, 13);
            this.pb3Q.Name = "pb3Q";
            this.pb3Q.Size = new System.Drawing.Size(100, 100);
            this.pb3Q.TabIndex = 1;
            this.pb3Q.TabStop = false;
            this.pb3Q.Click += new System.EventHandler(this.pb3Q_Click);
            // 
            // pbVLChiMong
            // 
            this.pbVLChiMong.Image = ((System.Drawing.Image)(resources.GetObject("pbVLChiMong.Image")));
            this.pbVLChiMong.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbVLChiMong.InitialImage")));
            this.pbVLChiMong.Location = new System.Drawing.Point(13, 13);
            this.pbVLChiMong.Name = "pbVLChiMong";
            this.pbVLChiMong.Size = new System.Drawing.Size(100, 100);
            this.pbVLChiMong.TabIndex = 0;
            this.pbVLChiMong.TabStop = false;
            this.pbVLChiMong.Click += new System.EventHandler(this.pbVLChiMong_Click);
            // 
            // TinTuc
            // 
            this.TinTuc.BackColor = System.Drawing.Color.White;
            this.TinTuc.Controls.Add(this.lbTuoiTre);
            this.TinTuc.Controls.Add(this.lbThanhNien);
            this.TinTuc.Controls.Add(this.lbGiaDinh);
            this.TinTuc.Controls.Add(this.lbVnExpress);
            this.TinTuc.Controls.Add(this.lbDanTri);
            this.TinTuc.Controls.Add(this.lbBaoMoi);
            this.TinTuc.Controls.Add(this.lb24H);
            this.TinTuc.Controls.Add(this.pbTuoiTre);
            this.TinTuc.Controls.Add(this.pbThanhNien);
            this.TinTuc.Controls.Add(this.pbTiepThiGiaDinh);
            this.TinTuc.Controls.Add(this.pbVnexpress);
            this.TinTuc.Controls.Add(this.pbDanTriNews);
            this.TinTuc.Controls.Add(this.pbBaoMoiNews);
            this.TinTuc.Controls.Add(this.pb24hNews);
            this.TinTuc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TinTuc.ForeColor = System.Drawing.Color.Black;
            this.TinTuc.Location = new System.Drawing.Point(4, 30);
            this.TinTuc.Name = "TinTuc";
            this.TinTuc.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.TinTuc.Size = new System.Drawing.Size(785, 429);
            this.TinTuc.TabIndex = 1;
            this.TinTuc.Text = "Tin Tức";
            // 
            // lbTuoiTre
            // 
            this.lbTuoiTre.AutoSize = true;
            this.lbTuoiTre.Location = new System.Drawing.Point(26, 246);
            this.lbTuoiTre.Name = "lbTuoiTre";
            this.lbTuoiTre.Size = new System.Drawing.Size(74, 21);
            this.lbTuoiTre.TabIndex = 25;
            this.lbTuoiTre.Text = "Tuổi Trẻ";
            // 
            // lbThanhNien
            // 
            this.lbThanhNien.AutoSize = true;
            this.lbThanhNien.Location = new System.Drawing.Point(664, 116);
            this.lbThanhNien.Name = "lbThanhNien";
            this.lbThanhNien.Size = new System.Drawing.Size(96, 21);
            this.lbThanhNien.TabIndex = 24;
            this.lbThanhNien.Text = "Thanh Niên";
            // 
            // lbGiaDinh
            // 
            this.lbGiaDinh.AutoSize = true;
            this.lbGiaDinh.Location = new System.Drawing.Point(547, 116);
            this.lbGiaDinh.Name = "lbGiaDinh";
            this.lbGiaDinh.Size = new System.Drawing.Size(87, 21);
            this.lbGiaDinh.TabIndex = 23;
            this.lbGiaDinh.Text = "TT && GĐ";
            // 
            // lbVnExpress
            // 
            this.lbVnExpress.AutoSize = true;
            this.lbVnExpress.Location = new System.Drawing.Point(409, 116);
            this.lbVnExpress.Name = "lbVnExpress";
            this.lbVnExpress.Size = new System.Drawing.Size(92, 21);
            this.lbVnExpress.TabIndex = 22;
            this.lbVnExpress.Text = "VnExpress";
            // 
            // lbDanTri
            // 
            this.lbDanTri.AutoSize = true;
            this.lbDanTri.Location = new System.Drawing.Point(289, 116);
            this.lbDanTri.Name = "lbDanTri";
            this.lbDanTri.Size = new System.Drawing.Size(68, 21);
            this.lbDanTri.TabIndex = 21;
            this.lbDanTri.Text = "Dân Trí";
            // 
            // lbBaoMoi
            // 
            this.lbBaoMoi.AutoSize = true;
            this.lbBaoMoi.Location = new System.Drawing.Point(156, 116);
            this.lbBaoMoi.Name = "lbBaoMoi";
            this.lbBaoMoi.Size = new System.Drawing.Size(75, 21);
            this.lbBaoMoi.TabIndex = 20;
            this.lbBaoMoi.Text = "Báo Mới";
            // 
            // lb24H
            // 
            this.lb24H.AutoSize = true;
            this.lb24H.Location = new System.Drawing.Point(26, 116);
            this.lb24H.Name = "lb24H";
            this.lb24H.Size = new System.Drawing.Size(76, 21);
            this.lb24H.TabIndex = 19;
            this.lb24H.Text = "Báo 24H";
            // 
            // pbTuoiTre
            // 
            this.pbTuoiTre.Image = ((System.Drawing.Image)(resources.GetObject("pbTuoiTre.Image")));
            this.pbTuoiTre.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbTuoiTre.InitialImage")));
            this.pbTuoiTre.Location = new System.Drawing.Point(13, 143);
            this.pbTuoiTre.Name = "pbTuoiTre";
            this.pbTuoiTre.Size = new System.Drawing.Size(100, 100);
            this.pbTuoiTre.TabIndex = 7;
            this.pbTuoiTre.TabStop = false;
            this.pbTuoiTre.Click += new System.EventHandler(this.pbTuoiTre_Click);
            // 
            // pbThanhNien
            // 
            this.pbThanhNien.Image = ((System.Drawing.Image)(resources.GetObject("pbThanhNien.Image")));
            this.pbThanhNien.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbThanhNien.InitialImage")));
            this.pbThanhNien.Location = new System.Drawing.Point(663, 13);
            this.pbThanhNien.Name = "pbThanhNien";
            this.pbThanhNien.Size = new System.Drawing.Size(100, 100);
            this.pbThanhNien.TabIndex = 6;
            this.pbThanhNien.TabStop = false;
            this.pbThanhNien.Click += new System.EventHandler(this.pbThanhNien_Click);
            // 
            // pbTiepThiGiaDinh
            // 
            this.pbTiepThiGiaDinh.Image = ((System.Drawing.Image)(resources.GetObject("pbTiepThiGiaDinh.Image")));
            this.pbTiepThiGiaDinh.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbTiepThiGiaDinh.InitialImage")));
            this.pbTiepThiGiaDinh.Location = new System.Drawing.Point(533, 13);
            this.pbTiepThiGiaDinh.Name = "pbTiepThiGiaDinh";
            this.pbTiepThiGiaDinh.Size = new System.Drawing.Size(100, 100);
            this.pbTiepThiGiaDinh.TabIndex = 5;
            this.pbTiepThiGiaDinh.TabStop = false;
            this.pbTiepThiGiaDinh.Click += new System.EventHandler(this.pbTiepThiGiaDinh_Click);
            // 
            // pbVnexpress
            // 
            this.pbVnexpress.Image = ((System.Drawing.Image)(resources.GetObject("pbVnexpress.Image")));
            this.pbVnexpress.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbVnexpress.InitialImage")));
            this.pbVnexpress.Location = new System.Drawing.Point(403, 13);
            this.pbVnexpress.Name = "pbVnexpress";
            this.pbVnexpress.Size = new System.Drawing.Size(100, 100);
            this.pbVnexpress.TabIndex = 4;
            this.pbVnexpress.TabStop = false;
            this.pbVnexpress.Click += new System.EventHandler(this.pbVnexpress_Click);
            // 
            // pbDanTriNews
            // 
            this.pbDanTriNews.Image = ((System.Drawing.Image)(resources.GetObject("pbDanTriNews.Image")));
            this.pbDanTriNews.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbDanTriNews.InitialImage")));
            this.pbDanTriNews.Location = new System.Drawing.Point(273, 13);
            this.pbDanTriNews.Name = "pbDanTriNews";
            this.pbDanTriNews.Size = new System.Drawing.Size(100, 100);
            this.pbDanTriNews.TabIndex = 3;
            this.pbDanTriNews.TabStop = false;
            this.pbDanTriNews.Click += new System.EventHandler(this.pbDanTriNews_Click);
            // 
            // pbBaoMoiNews
            // 
            this.pbBaoMoiNews.Image = ((System.Drawing.Image)(resources.GetObject("pbBaoMoiNews.Image")));
            this.pbBaoMoiNews.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbBaoMoiNews.InitialImage")));
            this.pbBaoMoiNews.Location = new System.Drawing.Point(143, 13);
            this.pbBaoMoiNews.Name = "pbBaoMoiNews";
            this.pbBaoMoiNews.Size = new System.Drawing.Size(100, 100);
            this.pbBaoMoiNews.TabIndex = 2;
            this.pbBaoMoiNews.TabStop = false;
            this.pbBaoMoiNews.Click += new System.EventHandler(this.pbBaoMoiNews_Click);
            // 
            // pb24hNews
            // 
            this.pb24hNews.Image = ((System.Drawing.Image)(resources.GetObject("pb24hNews.Image")));
            this.pb24hNews.InitialImage = ((System.Drawing.Image)(resources.GetObject("pb24hNews.InitialImage")));
            this.pb24hNews.Location = new System.Drawing.Point(13, 13);
            this.pb24hNews.Name = "pb24hNews";
            this.pb24hNews.Size = new System.Drawing.Size(100, 100);
            this.pb24hNews.TabIndex = 1;
            this.pb24hNews.TabStop = false;
            this.pb24hNews.Click += new System.EventHandler(this.pb24hNews_Click);
            // 
            // Nhac
            // 
            this.Nhac.BackColor = System.Drawing.Color.White;
            this.Nhac.Controls.Add(this.lbNhacSo);
            this.Nhac.Controls.Add(this.lbNhacVui);
            this.Nhac.Controls.Add(this.lbZingMp3);
            this.Nhac.Controls.Add(this.lbNCT);
            this.Nhac.Controls.Add(this.pbNhacSo);
            this.Nhac.Controls.Add(this.pbNhacVui);
            this.Nhac.Controls.Add(this.pbMp3Zing);
            this.Nhac.Controls.Add(this.pbNCT);
            this.Nhac.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Nhac.ForeColor = System.Drawing.Color.Black;
            this.Nhac.Location = new System.Drawing.Point(4, 30);
            this.Nhac.Name = "Nhac";
            this.Nhac.Size = new System.Drawing.Size(785, 429);
            this.Nhac.TabIndex = 2;
            this.Nhac.Text = "Nhạc";
            // 
            // lbNhacSo
            // 
            this.lbNhacSo.AutoSize = true;
            this.lbNhacSo.Location = new System.Drawing.Point(417, 116);
            this.lbNhacSo.Name = "lbNhacSo";
            this.lbNhacSo.Size = new System.Drawing.Size(75, 21);
            this.lbNhacSo.TabIndex = 23;
            this.lbNhacSo.Text = "Nhạc Số";
            // 
            // lbNhacVui
            // 
            this.lbNhacVui.AutoSize = true;
            this.lbNhacVui.Location = new System.Drawing.Point(283, 116);
            this.lbNhacVui.Name = "lbNhacVui";
            this.lbNhacVui.Size = new System.Drawing.Size(79, 21);
            this.lbNhacVui.TabIndex = 22;
            this.lbNhacVui.Text = "Nhạc Vui";
            // 
            // lbZingMp3
            // 
            this.lbZingMp3.AutoSize = true;
            this.lbZingMp3.Location = new System.Drawing.Point(151, 116);
            this.lbZingMp3.Name = "lbZingMp3";
            this.lbZingMp3.Size = new System.Drawing.Size(83, 21);
            this.lbZingMp3.TabIndex = 21;
            this.lbZingMp3.Text = "Zing Mp3";
            // 
            // lbNCT
            // 
            this.lbNCT.AutoSize = true;
            this.lbNCT.Location = new System.Drawing.Point(40, 116);
            this.lbNCT.Name = "lbNCT";
            this.lbNCT.Size = new System.Drawing.Size(48, 21);
            this.lbNCT.TabIndex = 20;
            this.lbNCT.Text = "NCT";
            // 
            // pbNhacSo
            // 
            this.pbNhacSo.Image = ((System.Drawing.Image)(resources.GetObject("pbNhacSo.Image")));
            this.pbNhacSo.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbNhacSo.InitialImage")));
            this.pbNhacSo.Location = new System.Drawing.Point(403, 13);
            this.pbNhacSo.Name = "pbNhacSo";
            this.pbNhacSo.Size = new System.Drawing.Size(100, 100);
            this.pbNhacSo.TabIndex = 5;
            this.pbNhacSo.TabStop = false;
            this.pbNhacSo.Click += new System.EventHandler(this.pbNhacSo_Click);
            // 
            // pbNhacVui
            // 
            this.pbNhacVui.Image = ((System.Drawing.Image)(resources.GetObject("pbNhacVui.Image")));
            this.pbNhacVui.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbNhacVui.InitialImage")));
            this.pbNhacVui.Location = new System.Drawing.Point(273, 13);
            this.pbNhacVui.Name = "pbNhacVui";
            this.pbNhacVui.Size = new System.Drawing.Size(100, 100);
            this.pbNhacVui.TabIndex = 4;
            this.pbNhacVui.TabStop = false;
            this.pbNhacVui.Click += new System.EventHandler(this.pbNhacVui_Click);
            // 
            // pbMp3Zing
            // 
            this.pbMp3Zing.Image = ((System.Drawing.Image)(resources.GetObject("pbMp3Zing.Image")));
            this.pbMp3Zing.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbMp3Zing.InitialImage")));
            this.pbMp3Zing.Location = new System.Drawing.Point(143, 13);
            this.pbMp3Zing.Name = "pbMp3Zing";
            this.pbMp3Zing.Size = new System.Drawing.Size(100, 100);
            this.pbMp3Zing.TabIndex = 3;
            this.pbMp3Zing.TabStop = false;
            this.pbMp3Zing.Click += new System.EventHandler(this.pbMp3Zing_Click);
            // 
            // pbNCT
            // 
            this.pbNCT.Image = ((System.Drawing.Image)(resources.GetObject("pbNCT.Image")));
            this.pbNCT.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbNCT.InitialImage")));
            this.pbNCT.Location = new System.Drawing.Point(13, 13);
            this.pbNCT.Name = "pbNCT";
            this.pbNCT.Size = new System.Drawing.Size(100, 100);
            this.pbNCT.TabIndex = 2;
            this.pbNCT.TabStop = false;
            this.pbNCT.Click += new System.EventHandler(this.pbNCT_Click);
            // 
            // UngDungCuaMay
            // 
            this.UngDungCuaMay.BackColor = System.Drawing.Color.White;
            this.UngDungCuaMay.Controls.Add(this.Zalo);
            this.UngDungCuaMay.Controls.Add(this.pbZaloPC);
            this.UngDungCuaMay.Controls.Add(this.lbVisual);
            this.UngDungCuaMay.Controls.Add(this.pbVisual);
            this.UngDungCuaMay.Controls.Add(this.lbBida);
            this.UngDungCuaMay.Controls.Add(this.pbBiDaFlash);
            this.UngDungCuaMay.Controls.Add(this.lbZaloPC);
            this.UngDungCuaMay.Controls.Add(this.pbRa2OFF);
            this.UngDungCuaMay.Controls.Add(this.lbChome);
            this.UngDungCuaMay.Controls.Add(this.pbChrome);
            this.UngDungCuaMay.Controls.Add(this.lbMyComputer);
            this.UngDungCuaMay.Controls.Add(this.pbMyComputer);
            this.UngDungCuaMay.Cursor = System.Windows.Forms.Cursors.Hand;
            this.UngDungCuaMay.ForeColor = System.Drawing.Color.Black;
            this.UngDungCuaMay.Location = new System.Drawing.Point(4, 30);
            this.UngDungCuaMay.Name = "UngDungCuaMay";
            this.UngDungCuaMay.Size = new System.Drawing.Size(785, 429);
            this.UngDungCuaMay.TabIndex = 4;
            this.UngDungCuaMay.Text = "Ứng Dụng Của Máy";
            // 
            // Zalo
            // 
            this.Zalo.AutoSize = true;
            this.Zalo.Location = new System.Drawing.Point(679, 116);
            this.Zalo.Name = "Zalo";
            this.Zalo.Size = new System.Drawing.Size(72, 21);
            this.Zalo.TabIndex = 33;
            this.Zalo.Text = "Zalo PC";
            // 
            // pbZaloPC
            // 
            this.pbZaloPC.Image = ((System.Drawing.Image)(resources.GetObject("pbZaloPC.Image")));
            this.pbZaloPC.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbZaloPC.InitialImage")));
            this.pbZaloPC.Location = new System.Drawing.Point(663, 13);
            this.pbZaloPC.Name = "pbZaloPC";
            this.pbZaloPC.Size = new System.Drawing.Size(100, 100);
            this.pbZaloPC.TabIndex = 32;
            this.pbZaloPC.TabStop = false;
            this.pbZaloPC.Click += new System.EventHandler(this.pbZaloPC_Click);
            // 
            // lbVisual
            // 
            this.lbVisual.AutoSize = true;
            this.lbVisual.Location = new System.Drawing.Point(273, 116);
            this.lbVisual.Name = "lbVisual";
            this.lbVisual.Size = new System.Drawing.Size(96, 21);
            this.lbVisual.TabIndex = 31;
            this.lbVisual.Text = "Visual 2013";
            // 
            // pbVisual
            // 
            this.pbVisual.Image = ((System.Drawing.Image)(resources.GetObject("pbVisual.Image")));
            this.pbVisual.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbVisual.InitialImage")));
            this.pbVisual.Location = new System.Drawing.Point(273, 13);
            this.pbVisual.Name = "pbVisual";
            this.pbVisual.Size = new System.Drawing.Size(100, 100);
            this.pbVisual.TabIndex = 30;
            this.pbVisual.TabStop = false;
            this.pbVisual.Click += new System.EventHandler(this.pbVisual_Click);
            // 
            // lbBida
            // 
            this.lbBida.AutoSize = true;
            this.lbBida.Location = new System.Drawing.Point(403, 116);
            this.lbBida.Name = "lbBida";
            this.lbBida.Size = new System.Drawing.Size(101, 21);
            this.lbBida.TabIndex = 29;
            this.lbBida.Text = "Game 9 Ball";
            // 
            // pbBiDaFlash
            // 
            this.pbBiDaFlash.Image = ((System.Drawing.Image)(resources.GetObject("pbBiDaFlash.Image")));
            this.pbBiDaFlash.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbBiDaFlash.InitialImage")));
            this.pbBiDaFlash.Location = new System.Drawing.Point(403, 13);
            this.pbBiDaFlash.Name = "pbBiDaFlash";
            this.pbBiDaFlash.Size = new System.Drawing.Size(100, 100);
            this.pbBiDaFlash.TabIndex = 28;
            this.pbBiDaFlash.TabStop = false;
            this.pbBiDaFlash.Click += new System.EventHandler(this.pbBiDaFlash_Click);
            // 
            // lbZaloPC
            // 
            this.lbZaloPC.AutoSize = true;
            this.lbZaloPC.Location = new System.Drawing.Point(535, 116);
            this.lbZaloPC.Name = "lbZaloPC";
            this.lbZaloPC.Size = new System.Drawing.Size(95, 21);
            this.lbZaloPC.TabIndex = 27;
            this.lbZaloPC.Text = "Red Alert 2";
            // 
            // pbRa2OFF
            // 
            this.pbRa2OFF.Image = ((System.Drawing.Image)(resources.GetObject("pbRa2OFF.Image")));
            this.pbRa2OFF.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbRa2OFF.InitialImage")));
            this.pbRa2OFF.Location = new System.Drawing.Point(533, 13);
            this.pbRa2OFF.Name = "pbRa2OFF";
            this.pbRa2OFF.Size = new System.Drawing.Size(100, 100);
            this.pbRa2OFF.TabIndex = 26;
            this.pbRa2OFF.TabStop = false;
            this.pbRa2OFF.Click += new System.EventHandler(this.pbRa2OFF_Click);
            // 
            // lbChome
            // 
            this.lbChome.AutoSize = true;
            this.lbChome.Location = new System.Drawing.Point(139, 116);
            this.lbChome.Name = "lbChome";
            this.lbChome.Size = new System.Drawing.Size(103, 21);
            this.lbChome.TabIndex = 25;
            this.lbChome.Text = "GG Chrome";
            // 
            // pbChrome
            // 
            this.pbChrome.Image = ((System.Drawing.Image)(resources.GetObject("pbChrome.Image")));
            this.pbChrome.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbChrome.InitialImage")));
            this.pbChrome.Location = new System.Drawing.Point(143, 13);
            this.pbChrome.Name = "pbChrome";
            this.pbChrome.Size = new System.Drawing.Size(100, 100);
            this.pbChrome.TabIndex = 24;
            this.pbChrome.TabStop = false;
            this.pbChrome.Click += new System.EventHandler(this.pbChrome_Click);
            // 
            // lbMyComputer
            // 
            this.lbMyComputer.AutoSize = true;
            this.lbMyComputer.Location = new System.Drawing.Point(6, 116);
            this.lbMyComputer.Name = "lbMyComputer";
            this.lbMyComputer.Size = new System.Drawing.Size(115, 21);
            this.lbMyComputer.TabIndex = 23;
            this.lbMyComputer.Text = "My Computer";
            // 
            // pbMyComputer
            // 
            this.pbMyComputer.Image = ((System.Drawing.Image)(resources.GetObject("pbMyComputer.Image")));
            this.pbMyComputer.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbMyComputer.InitialImage")));
            this.pbMyComputer.Location = new System.Drawing.Point(13, 13);
            this.pbMyComputer.Name = "pbMyComputer";
            this.pbMyComputer.Size = new System.Drawing.Size(100, 100);
            this.pbMyComputer.TabIndex = 3;
            this.pbMyComputer.TabStop = false;
            this.pbMyComputer.Click += new System.EventHandler(this.pbMyComputer_Click);
            // 
            // lbConnect
            // 
            this.lbConnect.AutoSize = true;
            this.lbConnect.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lbConnect.Location = new System.Drawing.Point(250, 467);
            this.lbConnect.Name = "lbConnect";
            this.lbConnect.Size = new System.Drawing.Size(242, 21);
            this.lbConnect.TabIndex = 0;
            this.lbConnect.Text = "Đã Kết Nối Được Với Server...";
            // 
            // tbMessage
            // 
            this.tbMessage.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tbMessage.Location = new System.Drawing.Point(608, 465);
            this.tbMessage.Name = "tbMessage";
            this.tbMessage.Size = new System.Drawing.Size(128, 29);
            this.tbMessage.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(742, 464);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(33, 30);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // rbMenuGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(776, 497);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tbMessage);
            this.Controls.Add(this.menuTabControl);
            this.Controls.Add(this.lbConnect);
            this.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.Name = "rbMenuGame";
            this.Text = "Menu Game";
            this.Load += new System.EventHandler(this.rbMain_Load);
            this.menuTabControl.ResumeLayout(false);
            this.GiaiTri.ResumeLayout(false);
            this.GiaiTri.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbBaVuong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGGPlus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTwister)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbYouTuBe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbZalo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbZingMe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFacebook)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbĐBVõLâm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRa2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGunny)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbKVTrenMay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3Q)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbVLChiMong)).EndInit();
            this.TinTuc.ResumeLayout(false);
            this.TinTuc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbTuoiTre)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbThanhNien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTiepThiGiaDinh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbVnexpress)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDanTriNews)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBaoMoiNews)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb24hNews)).EndInit();
            this.Nhac.ResumeLayout(false);
            this.Nhac.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbNhacSo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbNhacVui)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMp3Zing)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbNCT)).EndInit();
            this.UngDungCuaMay.ResumeLayout(false);
            this.UngDungCuaMay.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbZaloPC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbVisual)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBiDaFlash)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRa2OFF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbChrome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMyComputer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl menuTabControl;
        private System.Windows.Forms.TabPage GiaiTri;
        private System.Windows.Forms.TabPage TinTuc;
        private System.Windows.Forms.TabPage Nhac;
        private System.Windows.Forms.TabPage UngDungCuaMay;
        private System.Windows.Forms.Label lbConnect;
        private System.Windows.Forms.TextBox tbMessage;
        private System.Windows.Forms.PictureBox pbRa2;
        private System.Windows.Forms.PictureBox pbGunny;
        private System.Windows.Forms.PictureBox pbKVTrenMay;
        private System.Windows.Forms.PictureBox pb3Q;
        private System.Windows.Forms.PictureBox pbVLChiMong;
        private System.Windows.Forms.Label lbRa2;
        private System.Windows.Forms.Label lb3Q;
        private System.Windows.Forms.Label lbKVTrenMay;
        private System.Windows.Forms.Label lbGunny;
        private System.Windows.Forms.Label lbVLChiMong;
        private System.Windows.Forms.Label lbĐBVõLâm;
        private System.Windows.Forms.PictureBox pbĐBVõLâm;
        private System.Windows.Forms.PictureBox pbZalo;
        private System.Windows.Forms.PictureBox pbZingMe;
        private System.Windows.Forms.PictureBox pbFacebook;
        private System.Windows.Forms.PictureBox pbGGPlus;
        private System.Windows.Forms.PictureBox pbTwister;
        private System.Windows.Forms.PictureBox pbYouTuBe;
        private System.Windows.Forms.PictureBox pbBaVuong;
        private System.Windows.Forms.Label LbGGPlus;
        private System.Windows.Forms.Label lbZalo;
        private System.Windows.Forms.Label lbTwitter;
        private System.Windows.Forms.Label lbYouTuBe;
        private System.Windows.Forms.Label lbZingMe;
        private System.Windows.Forms.Label lbFaceBook;
        private System.Windows.Forms.Label lbBaVuongChiMong;
        private System.Windows.Forms.PictureBox pbTuoiTre;
        private System.Windows.Forms.PictureBox pbThanhNien;
        private System.Windows.Forms.PictureBox pbTiepThiGiaDinh;
        private System.Windows.Forms.PictureBox pbVnexpress;
        private System.Windows.Forms.PictureBox pbDanTriNews;
        private System.Windows.Forms.PictureBox pbBaoMoiNews;
        private System.Windows.Forms.PictureBox pb24hNews;
        private System.Windows.Forms.PictureBox pbNhacSo;
        private System.Windows.Forms.PictureBox pbNhacVui;
        private System.Windows.Forms.PictureBox pbMp3Zing;
        private System.Windows.Forms.PictureBox pbNCT;
        private System.Windows.Forms.Label lbTuoiTre;
        private System.Windows.Forms.Label lbThanhNien;
        private System.Windows.Forms.Label lbGiaDinh;
        private System.Windows.Forms.Label lbVnExpress;
        private System.Windows.Forms.Label lbDanTri;
        private System.Windows.Forms.Label lbBaoMoi;
        private System.Windows.Forms.Label lb24H;
        private System.Windows.Forms.Label lbNhacSo;
        private System.Windows.Forms.Label lbNhacVui;
        private System.Windows.Forms.Label lbZingMp3;
        private System.Windows.Forms.Label lbNCT;
        private System.Windows.Forms.Label lbMyComputer;
        private System.Windows.Forms.PictureBox pbMyComputer;
        private System.Windows.Forms.PictureBox pbChrome;
        private System.Windows.Forms.Label lbZaloPC;
        private System.Windows.Forms.PictureBox pbRa2OFF;
        private System.Windows.Forms.Label lbChome;
        private System.Windows.Forms.Label lbBida;
        private System.Windows.Forms.PictureBox pbBiDaFlash;
        private System.Windows.Forms.Label lbVisual;
        private System.Windows.Forms.PictureBox pbVisual;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pbZaloPC;
        private System.Windows.Forms.Label Zalo;




    }
}

